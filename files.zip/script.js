/* ============================================================
   Quality Vision Agent — script.js
   ============================================================ */

// ============================================================
// DATA
// ============================================================
const defectData = [
  { time:'17:44', type:'Porosity',            id:'DEF-8516', plant:'Shanghai, China', line:'Line 6', conf:78.8, camera:'CAM-06C', status:'REJECT', shift:'Shift A' },
  { time:'17:44', type:'Weld Flaw',           id:'DEF-8515', plant:'Shanghai, China', line:'Line 3', conf:97.6, camera:'CAM-03B', status:'HALT',   shift:'Shift A' },
  { time:'17:44', type:'Assembly Alignment',  id:'DEF-8514', plant:'Pune, India',     line:'Line 2', conf:87.8, camera:'CAM-02A', status:'HALT',   shift:'Shift A' },
  { time:'17:44', type:'Edge Chip',           id:'DEF-8513', plant:'Pune, India',     line:'Line 2', conf:82.0, camera:'CAM-02A', status:'HALT',   shift:'Shift A' },
  { time:'17:44', type:'Edge Chip',           id:'DEF-8512', plant:'Bangalore, India',line:'Line 1', conf:91.1, camera:'CAM-01A', status:'PASS',   shift:'Shift B' },
  { time:'17:43', type:'Foreign Object',      id:'DEF-8511', plant:'Pune, India',     line:'Line 5', conf:80.7, camera:'CAM-05B', status:'HALT',   shift:'Shift C' },
  { time:'17:43', type:'Porosity',            id:'DEF-8510', plant:'Shanghai, China', line:'Line 3', conf:89.0, camera:'CAM-03B', status:'HALT',   shift:'Shift C' },
  { time:'17:42', type:'Surface Crack',       id:'DEF-8509', plant:'Bangalore, India',line:'Line 1', conf:95.3, camera:'CAM-01A', status:'REJECT', shift:'Shift A' },
  { time:'17:42', type:'Weld Flaw',           id:'DEF-8508', plant:'Shanghai, China', line:'Line 6', conf:76.2, camera:'CAM-06C', status:'HALT',   shift:'Shift B' },
  { time:'17:41', type:'Coating Defect',      id:'DEF-8507', plant:'Pune, India',     line:'Line 4', conf:88.5, camera:'CAM-04A', status:'PASS',   shift:'Shift A' },
  { time:'17:41', type:'Dimensional Variance',id:'DEF-8506', plant:'Bangalore, India',line:'Line 2', conf:93.4, camera:'CAM-02A', status:'REJECT', shift:'Shift B' },
  { time:'17:40', type:'Surface Crack',       id:'DEF-8505', plant:'Shanghai, China', line:'Line 3', conf:84.7, camera:'CAM-03B', status:'HALT',   shift:'Shift C' },
];

const ncrData = [
  { id:'DEF-8492', type:'Surface Crack',       product:'HVAC Compressor A4', plant:'Bangalore, India', line:'Line 3', date:'28/05/2026', status:'Escalated', severity:'High',   ncrId:'NCR-1042', resolution:'N/A' },
  { id:'DEF-8489', type:'Dimensional Variance',product:'Chiller Unit B2',    plant:'Shanghai, China',  line:'Line 2', date:'27/05/2026', status:'Open',      severity:'Medium', ncrId:'NCR-1041', resolution:'N/A' },
  { id:'DEF-8491', type:'Foreign Object',      product:'Fan Coil Unit C1',   plant:'Pune, India',      line:'Line 5', date:'26/05/2026', status:'In Review', severity:'High',   ncrId:'NCR-1040', resolution:'12h' },
  { id:'DEF-8488', type:'Coating Defect',      product:'HVAC Compressor A4', plant:'Bangalore, India', line:'Line 1', date:'25/05/2026', status:'Closed',    severity:'Low',    ncrId:'NCR-1039', resolution:'8h' },
  { id:'DEF-8487', type:'Weld Flaw',           product:'Condenser Unit D3',  plant:'Shanghai, China',  line:'Line 6', date:'24/05/2026', status:'Closed',    severity:'High',   ncrId:'NCR-1038', resolution:'22h' },
  { id:'DEF-8490', type:'Edge Chip',           product:'Fan Coil Unit C1',   plant:'Pune, India',      line:'Line 4', date:'23/05/2026', status:'Open',      severity:'Medium', ncrId:'NCR-1037', resolution:'N/A' },
  { id:'DEF-8486', type:'Porosity',            product:'Chiller Unit B2',    plant:'Bangalore, India', line:'Line 3', date:'22/05/2026', status:'Closed',    severity:'Medium', ncrId:'NCR-1036', resolution:'31h' },
  { id:'DEF-8485', type:'Scratch',             product:'HVAC Compressor A4', plant:'Pune, India',      line:'Line 2', date:'21/05/2026', status:'Closed',    severity:'Low',    ncrId:'NCR-1035', resolution:'6h' },
];

const linePerformanceData = [
  { line:'Line 1', passRate:98.2, inspections:2140, defects:38,  status:'Good',    vsTarget:'+1.2pp' },
  { line:'Line 2', passRate:97.5, inspections:1980, defects:49,  status:'Good',    vsTarget:'+0.5pp' },
  { line:'Line 6', passRate:97.1, inspections:2010, defects:58,  status:'Good',    vsTarget:'+0.1pp' },
  { line:'Line 4', passRate:96.8, inspections:2050, defects:65,  status:'Warning', vsTarget:'-0.2pp' },
  { line:'Line 5', passRate:95.4, inspections:1870, defects:86,  status:'Warning', vsTarget:'-1.6pp' },
  { line:'Line 3', passRate:93.2, inspections:1750, defects:119, status:'Critical',vsTarget:'-3.8pp' },
];

// ============================================================
// NAV
// ============================================================
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    const pageId = 'page-' + item.dataset.page;
    const page = document.getElementById(pageId);
    if (page) {
      page.classList.add('active');
      initPageCharts(item.dataset.page);
    }
  });
});

// ============================================================
// INIT
// ============================================================
const chartsInitialized = {};

function initPageCharts(page) {
  if (chartsInitialized[page]) return;
  chartsInitialized[page] = true;
  if (page === 'live-inspection') {
    buildPassRateTrendChart();
  } else if (page === 'defect-library') {
    buildDefectRateTrendChart();
    buildDefectCatalogChart();
    buildNcrTrendChart();
  } else if (page === 'line-analytics') {
    buildPassRateByLineChart();
    buildLineDowntimeChart();
  } else if (page === 'model-intelligence') {
    buildFeatureImportanceChart();
    buildLatencyPercentilesChart();
  }
}

// Build all charts for initial page
document.addEventListener('DOMContentLoaded', () => {
  buildDefectTable();
  buildNcrTable();
  buildLinePerformanceTable();
  buildPassRateTrendChart();
  chartsInitialized['live-inspection'] = true;
  setupTooltips();
  setupFilters();
  // Simulate live feed
  setInterval(addLiveDefect, 8000);
});

// ============================================================
// DEFECT TABLE
// ============================================================
function buildDefectTable() {
  const tbody = document.getElementById('defectTableBody');
  tbody.innerHTML = defectData.map(d => `
    <tr>
      <td>${d.time}</td>
      <td><strong>${d.type}</strong></td>
      <td style="color:#94a3b8">${d.id}</td>
      <td>${d.plant}</td>
      <td>${d.line}</td>
      <td>${getConfBadge(d.conf)}</td>
      <td>${d.camera}</td>
      <td>${getStatusBadge(d.status)}</td>
      <td>${d.shift}</td>
      <td>
        <div style="display:flex;gap:6px;align-items:center;">
          <button class="action-btn btn-assign" onclick="openModal('Assign Defect','Assign ${d.id} to a quality engineer for review.')">👤 Assign</button>
          <button class="action-btn btn-escalate" onclick="openModal('Escalate Defect','Escalate ${d.id} to management. This will trigger an immediate review.')">🚫 Escalate</button>
          <button class="action-btn btn-ncr" onclick="openModal('Create NCR','Create a Non-Conformance Report for ${d.id}.')">📋 NCR</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function getStatusBadge(status) {
  const map = { 'PASS':'badge-pass','HALT':'badge-halt','REJECT':'badge-reject' };
  return `<span class="status-badge ${map[status]||'badge-halt'}">${status}</span>`;
}

function getConfBadge(conf) {
  let cls = conf >= 90 ? 'conf-high' : conf >= 80 ? 'conf-med' : 'conf-low-val';
  return `<span class="conf-badge ${cls}">${conf}%</span>`;
}

let defectCounter = 8516;
function addLiveDefect() {
  defectCounter++;
  const types = ['Porosity','Weld Flaw','Edge Chip','Surface Crack','Foreign Object','Coating Defect','Assembly Alignment'];
  const plants = ['Shanghai, China','Pune, India','Bangalore, India'];
  const lines = ['Line 1','Line 2','Line 3','Line 4','Line 5','Line 6'];
  const cams = ['CAM-01A','CAM-02A','CAM-03B','CAM-04A','CAM-05B','CAM-06C'];
  const statuses = ['PASS','HALT','REJECT'];
  const shifts = ['Shift A','Shift B','Shift C'];
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  const newDefect = {
    time: timeStr,
    type: types[Math.floor(Math.random()*types.length)],
    id: `DEF-${defectCounter}`,
    plant: plants[Math.floor(Math.random()*plants.length)],
    line: lines[Math.floor(Math.random()*lines.length)],
    conf: +(70 + Math.random()*28).toFixed(1),
    camera: cams[Math.floor(Math.random()*cams.length)],
    status: statuses[Math.floor(Math.random()*statuses.length)],
    shift: shifts[Math.floor(Math.random()*shifts.length)]
  };
  defectData.unshift(newDefect);
  if (defectData.length > 20) defectData.pop();
  buildDefectTable();
  // Update record count
  const rc = document.querySelector('.record-count');
  if (rc) {
    const cur = parseInt(rc.textContent) || 42;
    rc.textContent = (cur + 1) + ' Records';
  }
}

// ============================================================
// NCR TABLE
// ============================================================
function buildNcrTable() {
  const tbody = document.getElementById('ncrTableBody');
  tbody.innerHTML = ncrData.map(d => `
    <tr>
      <td style="color:#94a3b8">${d.id}</td>
      <td><strong>${d.type}</strong></td>
      <td>${d.product}</td>
      <td>${d.plant}</td>
      <td>${d.line}</td>
      <td>${d.date}</td>
      <td>${getNcrStatusBadge(d.status)}</td>
      <td>${getSeverityText(d.severity)}</td>
      <td>${d.ncrId}</td>
      <td>${getResolutionTime(d.resolution)}</td>
    </tr>
  `).join('');
}

function getNcrStatusBadge(s) {
  const map = { 'Escalated':'badge-escalated','Open':'badge-open','In Review':'badge-in-review','Closed':'badge-closed' };
  return `<span class="status-badge ${map[s]||'badge-open'}">${s}</span>`;
}
function getSeverityText(s) {
  const map = { 'High':'red','Medium':'orange','Low':'green' };
  return `<span style="font-weight:700;color:var(--${map[s]||'text-primary'})">${s}</span>`;
}
function getResolutionTime(r) {
  if (r === 'N/A') return `<span style="color:#94a3b8">N/A</span>`;
  return `<span style="color:var(--green);font-weight:700">${r}</span>`;
}

// ============================================================
// LINE PERFORMANCE TABLE
// ============================================================
function buildLinePerformanceTable() {
  const tbody = document.getElementById('linePerformanceBody');
  tbody.innerHTML = linePerformanceData.map(d => {
    const statusMap = { 'Good':'badge-good','Warning':'badge-warning','Critical':'badge-critical' };
    const vsColor = d.vsTarget.startsWith('+') ? 'green' : 'red';
    return `
      <tr>
        <td><strong>${d.line}</strong></td>
        <td><strong>${d.passRate}%</strong></td>
        <td>${d.inspections.toLocaleString()}</td>
        <td style="color:var(--red);font-weight:700">${d.defects}</td>
        <td><span class="status-badge ${statusMap[d.status]}">${d.status}</span></td>
        <td style="color:var(--${vsColor});font-weight:700">${d.vsTarget}</td>
      </tr>
    `;
  }).join('');
}

// ============================================================
// CHART: Pass Rate Trend
// ============================================================
function buildPassRateTrendChart() {
  const ctx = document.getElementById('passRateTrendChart');
  if (!ctx) return;
  const labels = ['06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00'];
  const data = [97.2, 97.8, 97.5, 97.7, 98.1, 98.4, 98.3, 97.9, 97.6, 97.9];

  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Pass Rate',
        data,
        borderColor: '#10b981',
        backgroundColor: 'rgba(16,185,129,0.08)',
        borderWidth: 2.5,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: '#10b981',
        pointRadius: 4,
        pointHoverRadius: 6,
      },{
        label: 'Target 97%',
        data: labels.map(() => 97),
        borderColor: '#cbd5e1',
        borderWidth: 1.5,
        borderDash: [5, 4],
        pointRadius: 0,
        fill: false,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'white',
          titleColor: '#0f172a',
          bodyColor: '#10b981',
          borderColor: '#e2e8f0',
          borderWidth: 1,
          padding: 10,
          titleFont: { size: 13, weight: '700' },
          bodyFont: { size: 13, weight: '700' },
          callbacks: {
            title: ctx => ctx[0].label,
            label: ctx => ctx.datasetIndex === 0 ? `Pass Rate : ${ctx.parsed.y}%` : null,
            filter: item => item.datasetIndex === 0
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 }, color: '#94a3b8' },
          border: { display: false }
        },
        y: {
          min: 95,
          max: 100,
          ticks: {
            font: { size: 11 }, color: '#94a3b8',
            callback: v => v + '%'
          },
          grid: { color: '#f1f5f9', drawBorder: false },
          border: { display: false }
        }
      }
    }
  });
}

// ============================================================
// CHART: Defect Rate Trend (combo)
// ============================================================
let defectTrendChart = null;

const defectTrendData = {
  Hourly: {
    labels: ['06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00'],
    bars:   [600, 750, 900, 820, 1050, 1020, 800, 960, 880, 1180],
    line:   [18, 25, 28, 26, 31, 29, 17, 33, 27, 34]
  },
  Daily: {
    labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    bars:   [4200, 3800, 4500, 4100, 4800, 3200, 3600],
    line:   [42, 38, 46, 41, 48, 32, 36]
  },
  Weekly: {
    labels: ['W1','W2','W3','W4','W5','W6'],
    bars:   [29000, 27000, 31000, 28000, 33000, 30000],
    line:   [210, 195, 230, 205, 245, 220]
  }
};

function buildDefectRateTrendChart() {
  const ctx = document.getElementById('defectRateTrendChart');
  if (!ctx) return;
  const d = defectTrendData.Hourly;

  defectTrendChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: d.labels,
      datasets: [
        {
          label: 'Parts Inspected',
          data: d.bars,
          backgroundColor: 'rgba(99,140,230,0.75)',
          borderRadius: 4,
          yAxisID: 'y',
          order: 2
        },
        {
          label: 'Defects Found',
          data: d.line,
          type: 'line',
          borderColor: '#ef4444',
          backgroundColor: 'transparent',
          borderWidth: 2,
          tension: 0.4,
          pointBackgroundColor: '#ef4444',
          pointRadius: 4,
          yAxisID: 'y1',
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          labels: { font: { size: 11 }, usePointStyle: true, boxWidth: 12 }
        },
        tooltip: { mode: 'index', intersect: false }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#94a3b8' }, border: { display: false } },
        y: {
          position: 'left',
          ticks: { font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        },
        y1: {
          position: 'right',
          ticks: { font: { size: 11 }, color: '#94a3b8' },
          grid: { drawOnChartArea: false },
          border: { display: false }
        }
      }
    }
  });
}

function updateDefectTrendChart() {
  const period = document.getElementById('defectTrendPeriod').value;
  const d = defectTrendData[period];
  if (!defectTrendChart || !d) return;
  defectTrendChart.data.labels = d.labels;
  defectTrendChart.data.datasets[0].data = d.bars;
  defectTrendChart.data.datasets[1].data = d.line;
  defectTrendChart.update();
}

// ============================================================
// CHART: Defect Catalog (horizontal bar)
// ============================================================
let defectCatalogChart = null;
let activeDefectFilter = null;

function buildDefectCatalogChart() {
  const ctx = document.getElementById('defectCatalogChart');
  if (!ctx) return;
  const labels   = ['Surface Crack','Scratch','Foreign Object','Edge Chip','Dimensional Variance','Coating Defect','Weld Flaw','Porosity'];
  const values   = [142, 121, 98, 88, 76, 54, 42, 28];
  const colors   = ['#ef4444','#10b981','#ef4444','#f59e0b','#f59e0b','#10b981','#ef4444','#f59e0b'];

  defectCatalogChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: values, backgroundColor: colors, borderRadius: 4, barThickness: 14 }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: { label: ctx => ` ${ctx.parsed.x} defects` }
        }
      },
      scales: {
        x: { grid: { color: '#f1f5f9' }, ticks: { font: { size: 10 }, color: '#94a3b8' }, border: { display: false } },
        y: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#0f172a' }, border: { display: false } }
      },
      onClick(evt, elements) {
        if (!elements.length) return;
        const idx = elements[0].index;
        const label = labels[idx];
        filterNcrByType(label);
        showToast(`Filtering NCR table by: ${label}`);
      }
    }
  });
}

function filterNcrByType(type) {
  activeDefectFilter = activeDefectFilter === type ? null : type;
  const filtered = activeDefectFilter ? ncrData.filter(d => d.type === activeDefectFilter) : ncrData;
  const tbody = document.getElementById('ncrTableBody');
  if (!tbody) return;
  tbody.innerHTML = filtered.map(d => `
    <tr>
      <td style="color:#94a3b8">${d.id}</td>
      <td><strong>${d.type}</strong></td>
      <td>${d.product}</td>
      <td>${d.plant}</td>
      <td>${d.line}</td>
      <td>${d.date}</td>
      <td>${getNcrStatusBadge(d.status)}</td>
      <td>${getSeverityText(d.severity)}</td>
      <td>${d.ncrId}</td>
      <td>${getResolutionTime(d.resolution)}</td>
    </tr>
  `).join('') || `<tr><td colspan="10" style="text-align:center;color:#94a3b8;padding:20px;">No records match filter</td></tr>`;
}

// ============================================================
// CHART: NCR Trend
// ============================================================
function buildNcrTrendChart() {
  const ctx = document.getElementById('ncrTrendChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['W1','W2','W3','W4','W5','W6'],
      datasets: [{
        data: [38, 32, 28, 22, 18, 14],
        backgroundColor: '#3b82f6',
        borderRadius: 4,
        barThickness: 28
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#94a3b8' }, border: { display: false } },
        y: {
          max: 60,
          ticks: { stepSize: 30, font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        }
      }
    }
  });
}

// ============================================================
// CHART: Pass Rate By Line
// ============================================================
function buildPassRateByLineChart() {
  const ctx = document.getElementById('passRateByLineChart');
  if (!ctx) return;
  const data = [98.2, 97.5, 97.1, 96.8, 95.4, 93.2];
  const colors = data.map(v => v >= 97 ? '#10b981' : v >= 95 ? '#f59e0b' : '#ef4444');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Line 1','Line 2','Line 6','Line 4','Line 5','Line 3'],
      datasets: [{
        data,
        backgroundColor: colors,
        borderRadius: 4,
        barThickness: 40
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.y}%` } },
        datalabels: { display: false }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 12 }, color: '#0f172a' }, border: { display: false } },
        y: {
          min: 88, max: 100,
          ticks: { callback: v => v+'%', font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        }
      }
    },
    plugins: [{
      id: 'topLabels',
      afterDatasetsDraw(chart) {
        const { ctx: c, data } = chart;
        c.save();
        chart.getDatasetMeta(0).data.forEach((bar, i) => {
          c.fillStyle = '#0f172a';
          c.font = '700 12px system-ui';
          c.textAlign = 'center';
          c.fillText(data.datasets[0].data[i] + '%', bar.x, bar.y - 6);
        });
        c.restore();
      }
    }]
  });
}

// ============================================================
// CHART: Line Downtime
// ============================================================
function buildLineDowntimeChart() {
  const ctx = document.getElementById('lineDowntimeChart');
  if (!ctx) return;
  const values = [0.8, 1.4, 4.2, 1.1, 2.8, 0.9];
  const colors = values.map(v => v >= 3 ? '#ef4444' : v >= 2 ? '#f59e0b' : '#10b981');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Line 1','Line 2','Line 3','Line 4','Line 5','Line 6'],
      datasets: [{
        data: values,
        backgroundColor: colors,
        borderRadius: 4,
        barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.x}h` } }
      },
      scales: {
        x: {
          min: 0, max: 8,
          ticks: { callback: v => v+'h', font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        },
        y: {
          grid: { display: false },
          ticks: { font: { size: 12 }, color: '#0f172a' },
          border: { display: false }
        }
      }
    },
    plugins: [{
      id: 'rightLabels',
      afterDatasetsDraw(chart) {
        const { ctx: c, data } = chart;
        c.save();
        chart.getDatasetMeta(0).data.forEach((bar, i) => {
          c.fillStyle = '#0f172a';
          c.font = '600 12px system-ui';
          c.textAlign = 'left';
          c.fillText(data.datasets[0].data[i] + 'h', bar.x + 6, bar.y + 4);
        });
        c.restore();
      }
    }]
  });
}

// ============================================================
// CHART: Feature Importance
// ============================================================
function buildFeatureImportanceChart() {
  const ctx = document.getElementById('featureImportanceChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Vibration RMS','Thermal Delta','Pressure Variance','Run Hours','Ambient Temp','Load Factor'],
      datasets: [{
        data: [34, 24, 17, 12, 8, 5],
        backgroundColor: '#3b82f6',
        borderRadius: 4,
        barThickness: 16
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.x}%` } }
      },
      scales: {
        x: {
          ticks: { callback: v => v+'%', font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        },
        y: {
          grid: { display: false },
          ticks: { font: { size: 12 }, color: '#0f172a' },
          border: { display: false }
        }
      }
    },
    plugins: [{
      id: 'rightPct',
      afterDatasetsDraw(chart) {
        const { ctx: c, data } = chart;
        c.save();
        chart.getDatasetMeta(0).data.forEach((bar, i) => {
          c.fillStyle = '#0f172a';
          c.font = '600 12px system-ui';
          c.textAlign = 'left';
          c.fillText(data.datasets[0].data[i] + '%', bar.x + 6, bar.y + 4);
        });
        c.restore();
      }
    }]
  });
}

// ============================================================
// CHART: Latency Percentiles
// ============================================================
function buildLatencyPercentilesChart() {
  const ctx = document.getElementById('latencyPercentilesChart');
  if (!ctx) return;
  const vals = [6.2, 7.1, 7.8, 8.0, 8.5];

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['P50','P75','P90','P95','P99'],
      datasets: [{
        data: vals,
        backgroundColor: '#8b5cf6',
        borderRadius: 4,
        barThickness: 36
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.y} ms` } }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 12 }, color: '#0f172a' }, border: { display: false } },
        y: {
          min: 0, max: 12,
          ticks: { callback: v => v+' ms', font: { size: 11 }, color: '#94a3b8' },
          grid: { color: '#f1f5f9' },
          border: { display: false }
        }
      }
    },
    plugins: [{
      id: 'topMs',
      afterDatasetsDraw(chart) {
        const { ctx: c, data } = chart;
        c.save();
        chart.getDatasetMeta(0).data.forEach((bar, i) => {
          c.fillStyle = '#0f172a';
          c.font = '600 11px system-ui';
          c.textAlign = 'center';
          c.fillText(data.datasets[0].data[i] + ' ms', bar.x, bar.y - 7);
        });
        c.restore();
      }
    }]
  });
}

// ============================================================
// TOOLTIPS
// ============================================================
function setupTooltips() {
  const tooltip = document.getElementById('tooltip');

  document.addEventListener('mouseover', e => {
    const el = e.target.closest('[data-tooltip]');
    if (!el) return;
    tooltip.textContent = el.dataset.tooltip;
    tooltip.classList.add('visible');
  });

  document.addEventListener('mousemove', e => {
    tooltip.style.left = (e.clientX + 14) + 'px';
    tooltip.style.top = (e.clientY - 30) + 'px';
  });

  document.addEventListener('mouseout', e => {
    if (!e.target.closest('[data-tooltip]')) return;
    tooltip.classList.remove('visible');
  });
}

// ============================================================
// TOAST
// ============================================================
let toastTimer = null;
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 3000);
}

// ============================================================
// MODAL
// ============================================================
function openModal(title, body) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').textContent = body;
  document.getElementById('modalOverlay').classList.add('visible');
}
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('visible');
}

// ============================================================
// HEADER BUTTONS
// ============================================================
function exportNCRs() {
  showToast('Exporting NCRs to CSV...');
  setTimeout(() => {
    const rows = [['Defect ID','Type','Product','Plant','Line','Date','Status','Severity','NCR ID','Resolution Time']];
    ncrData.forEach(d => rows.push([d.id,d.type,d.product,d.plant,d.line,d.date,d.status,d.severity,d.ncrId,d.resolution]));
    const csv = rows.map(r => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'NCR_Export.csv';
    a.click();
  }, 500);
}

function syncMES() {
  showToast('Syncing with MES system...');
  const btn = document.querySelector('.btn-sync');
  if (btn) {
    btn.textContent = '⟳ Syncing...';
    setTimeout(() => { btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Sync MES'; showToast('MES sync complete ✓'); }, 2000);
  }
}

// ============================================================
// FILTERS
// ============================================================
function setupFilters() {
  // Attach live filtering to defect table filters
  ['filter-plant-li','filter-shift-li','filter-line-li','filter-date-li'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', applyDefectFilters);
  });
}

function applyDefectFilters() {
  const plant = document.getElementById('filter-plant-li')?.value || 'All Plants';
  const shift = document.getElementById('filter-shift-li')?.value || 'All Shifts';
  const line  = document.getElementById('filter-line-li')?.value  || 'All Lines';

  const filtered = defectData.filter(d => {
    return (plant === 'All Plants' || d.plant === plant) &&
           (shift === 'All Shifts' || d.shift === shift) &&
           (line  === 'All Lines'  || d.line  === line);
  });

  const tbody = document.getElementById('defectTableBody');
  if (!tbody) return;
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align:center;color:#94a3b8;padding:20px;">No records match the selected filters</td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.map(d => `
    <tr>
      <td>${d.time}</td>
      <td><strong>${d.type}</strong></td>
      <td style="color:#94a3b8">${d.id}</td>
      <td>${d.plant}</td>
      <td>${d.line}</td>
      <td>${getConfBadge(d.conf)}</td>
      <td>${d.camera}</td>
      <td>${getStatusBadge(d.status)}</td>
      <td>${d.shift}</td>
      <td>
        <div style="display:flex;gap:6px;align-items:center;">
          <button class="action-btn btn-assign" onclick="openModal('Assign Defect','Assign ${d.id} to a quality engineer.')">👤 Assign</button>
          <button class="action-btn btn-escalate" onclick="openModal('Escalate Defect','Escalate ${d.id} to management.')">🚫 Escalate</button>
          <button class="action-btn btn-ncr" onclick="openModal('Create NCR','Create NCR for ${d.id}.')">📋 NCR</button>
        </div>
      </td>
    </tr>
  `).join('');
}

// ============================================================
// TABLE SORTING
// ============================================================
document.addEventListener('click', e => {
  const th = e.target.closest('th');
  if (!th) return;
  const table = th.closest('table');
  if (!table) return;
  const tbody = table.querySelector('tbody');
  if (!tbody) return;
  const idx = Array.from(th.parentNode.children).indexOf(th);
  const rows = Array.from(tbody.querySelectorAll('tr'));
  const dir = th.dataset.sort === 'asc' ? -1 : 1;
  th.parentNode.querySelectorAll('th').forEach(h => delete h.dataset.sort);
  th.dataset.sort = dir === 1 ? 'asc' : 'desc';
  rows.sort((a, b) => {
    const av = a.cells[idx]?.textContent.trim() || '';
    const bv = b.cells[idx]?.textContent.trim() || '';
    return av.localeCompare(bv, undefined, { numeric: true }) * dir;
  });
  rows.forEach(r => tbody.appendChild(r));
});
